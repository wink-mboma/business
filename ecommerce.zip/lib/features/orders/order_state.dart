import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../products/product_state.dart';

class OrderItemSnapshot {
  const OrderItemSnapshot({required this.productId, required this.name, required this.imageUrl, required this.unitPrice, required this.quantity, this.size, this.color});
  final String productId, name, imageUrl;
  final double unitPrice;
  final int quantity;
  final String? size, color;
  double get total => unitPrice * quantity;
}

class StoreOrder {
  const StoreOrder({required this.id, required this.createdAt, required this.items, required this.subtotal, required this.delivery, required this.total, required this.paymentMethod, required this.paymentStatus, required this.status, required this.address});
  final String id;
  final DateTime createdAt;
  final List<OrderItemSnapshot> items;
  final double subtotal, delivery, total;
  final String paymentMethod, paymentStatus, status, address;
}

class OrdersController extends StateNotifier<List<StoreOrder>> {
  OrdersController() : super(const []);
  StoreOrder createDemoOrder({required List<CartLine> cart, required double total, required double delivery, required String method, required String address}) {
    final now = DateTime.now();
    final id = 'MS-${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}-${(now.microsecondsSinceEpoch % 1000000).toString().padLeft(6, '0')}';
    final items = cart.map((line) => OrderItemSnapshot(productId: line.product.id, name: line.product.name, imageUrl: line.product.imageUrl, unitPrice: line.product.price, quantity: line.quantity, size: line.size, color: line.color)).toList(growable: false);
    final order = StoreOrder(id: id, createdAt: now, items: items, subtotal: items.fold<double>(0, (sum, item) => sum + item.total), delivery: delivery, total: total, paymentMethod: method, paymentStatus: 'Pending', status: 'Processing', address: address);
    state = [order, ...state];
    return order;
  }
}
final ordersProvider = StateNotifierProvider<OrdersController, List<StoreOrder>>((ref) => OrdersController());
