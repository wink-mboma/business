/// Configure this URL for the device you are running during local development.
/// Android emulator: http://10.0.2.2/mono-store-admin/api
/// Windows / Flutter web on the same PC: http://localhost/mono-store-admin/api
/// Physical phone: http://YOUR_PC_LAN_IP/mono-store-admin/api
class ApiConfig {
  ApiConfig._();
  static const String baseUrl = String.fromEnvironment(
    'MONO_API_BASE_URL',
    defaultValue: 'http://10.0.2.2/mono-store-admin/api',
  );
  static const Duration timeout = Duration(seconds: 15);
}
